package com.edu.thss.smartdental.model.general;

public class SDOralInfo {
	public int positionNum; //����
	public int position; //����λ��
	public int isPrimary; //�Ƿ�Ϊ����
	public int state;
	public String mesialShift;
	public String occlusaShift;
	public String lipShift;
	public String rotate;
	public String mesialRotate;
	public String lipRotate;
	
}
