package com.edu.thss.smartdental.model.tooth;

public enum ToothNumberingNomenclature {
	///<summary>0- American</summary>
	Universal,
	///<summary>1- International</summary>
	FDI,
	///<summary>2- </summary>
	Haderup,
	///<summary>3- Ortho</summary>
	Palmer
}
