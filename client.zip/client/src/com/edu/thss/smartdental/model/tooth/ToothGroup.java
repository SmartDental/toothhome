package com.edu.thss.smartdental.model.tooth;

public class ToothGroup {

	public boolean visible;
	public int paintColor;
	public ToothGroupType groupType;
	public int[][][] faces;
}
