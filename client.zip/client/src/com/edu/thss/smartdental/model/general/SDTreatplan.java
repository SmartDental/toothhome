package com.edu.thss.smartdental.model.general;

public class SDTreatplan {
	public String createTime;
	public String content;
	public String cost;

}
