package com.edu.thss.smartdental.model.general;

public class SDDocument {
       public String name;
       public String createTime;
       public String description;
       public String contentPath;
       public boolean isMark;
       public boolean isRead;
       public boolean isHidden;
}
