package com.edu.thss.smartdental.model.tooth;

public class ToothInitial {

}
