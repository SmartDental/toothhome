package com.edu.thss.smartdental.model.tooth;

public enum toothInitialType {
	Miss,Primary
}
